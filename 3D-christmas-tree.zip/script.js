/**
 * Engine & Setup
 */
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d", { alpha: false }); // Optimize for no transparency on canvas itself

let width, height, cx, cy;
let time = 0;

// Settings
const config = {
    particleCount: 1100,
    snowCount: 150,
    focalLength: 800,
    baseSpeed: 0.005,
    globalSizeScale: 1.5,
    rotationSpeedMult: 1.0,
    lightMode: "sparkle",
};

// Palettes
const PALETTES = [
    { name: "Classic", colors: ["#ff0000", "#00ff00", "#ffd700", "#ffffff"] },
    { name: "Midnight", colors: ["#81ecec", "#74b9ff", "#a29bfe", "#dfe6e9"] },
    { name: "Royal", colors: ["#e056fd", "#be2edd", "#f0932b", "#ffbe76"] },
    { name: "Golden", colors: ["#f1c40f", "#f39c12", "#e67e22", "#fff"] },
];
let paletteIdx = 0;

// Mouse/Touch State
const mouse = { x: 0, y: 0 };
const rotation = { x: 0, y: 0, targetX: 0, targetY: 0 };

// Pre-rendered Sprites (Performance Hack)
const sprites = {};

/**
 * Pre-render particle glow to offscreen canvas
 * This improves performance by 10x compared to using shadowBlur every frame
 */
function generateSprites() {
    const colors = new Set(PALETTES.flatMap((p) => p.colors));
    colors.add("#ffffff"); // Snow

    colors.forEach((color) => {
        const sCanvas = document.createElement("canvas");
        const size = 32; // Texture size
        sCanvas.width = size;
        sCanvas.height = size;
        const sCtx = sCanvas.getContext("2d");
        const center = size / 2;

        // Radial gradient for soft glow
        const g = sCtx.createRadialGradient(
            center,
            center,
            0,
            center,
            center,
            center
        );
        g.addColorStop(0, color);
        g.addColorStop(0.2, color); // Solid core
        g.addColorStop(0.4, adjustAlpha(color, 0.5));
        g.addColorStop(1, "transparent");

        sCtx.fillStyle = g;
        sCtx.fillRect(0, 0, size, size);

        sprites[color] = sCanvas;
    });
}

// Helper to add alpha to hex
function adjustAlpha(color, opacity) {
    if (color.startsWith("#")) {
        let hex = color.slice(1);
        // Handle short hex like #fff
        if (hex.length === 3) {
            hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
        }
        let r = parseInt(hex.slice(0, 2), 16);
        let g = parseInt(hex.slice(2, 4), 16);
        let b = parseInt(hex.slice(4, 6), 16);
        return `rgba(${r}, ${g}, ${b}, ${opacity})`;
    }
    return color;
}

/**
 * Entities
 */
class Point {
    constructor() {
        this.x = 0;
        this.y = 0;
        this.z = 0;
        this.ox = 0;
        this.oy = 0;
        this.oz = 0; // Original positions
    }

    project() {
        // Rotate Y
        const totalRotX =
            rotation.x + time * config.baseSpeed * config.rotationSpeedMult;
        const cosY = Math.cos(totalRotX);
        const sinY = Math.sin(totalRotX);

        let x1 = this.x * cosY - this.z * sinY;
        let z1 = this.z * cosY + this.x * sinY;

        // Rotate X (Tilt)
        const cosX = Math.cos(rotation.y);
        const sinX = Math.sin(rotation.y);

        let y1 = this.y * cosX - z1 * sinX;
        let z2 = z1 * cosX + this.y * sinX;

        // Camera Push
        z2 += config.focalLength + 200;

        // Perspective Scale
        const scale = config.focalLength / z2;

        return {
            x: cx + x1 * scale,
            y: cy + y1 * scale,
            scale: scale,
            depth: z2,
            visible: z2 > 10, // Clipping plane
        };
    }
}

class TreeLight extends Point {
    constructor(idx) {
        super();
        this.idx = idx;
        this.reset();
    }

    reset() {
        // Cone Distribution
        const h = Math.random(); // 0 to 1 height
        const y = h * 800 - 400; // -400 to 400
        // Fixed: Pointy top (radius 0 at y=-400), Wide base (radius 300 at y=400)
        // Use a power function for a slightly curved, more natural tree shape, or linear for geometric cone
        const radius = Math.pow(h, 0.8) * 350;

        // Golden Angle spiral
        const angle = this.idx * 2.3999632;

        this.x = Math.cos(angle) * radius;
        this.y = y;
        this.z = Math.sin(angle) * radius;

        // Store original coords for pulse return
        this.ox = this.x;
        this.oy = this.y;
        this.oz = this.z;

        this.color = this.pickColor();
        this.sizeBase = 1 + Math.random() * 2;
        this.blinkOffset = Math.random() * 100;
        this.pulseOffset = 0;
    }

    pickColor() {
        const p = PALETTES[paletteIdx].colors;
        return p[Math.floor(Math.random() * p.length)];
    }

    update() {
        // Pulse Logic
        if (pulse.active) {
            const dist = Math.abs(this.y - pulse.y);
            if (dist < 100) {
                const force = (1 - dist / 100) * 80;
                const angle = Math.atan2(this.z, this.x);
                this.x = this.ox + Math.cos(angle) * force;
                this.z = this.oz + Math.sin(angle) * force;

                // Temporary White flash
                if (dist < 20) this.tempColor = "#ffffff";
            } else {
                // Return spring
                this.x += (this.ox - this.x) * 0.1;
                this.z += (this.oz - this.z) * 0.1;
                this.tempColor = null;
            }
        } else if (this.x !== this.ox) {
            this.x += (this.ox - this.x) * 0.1;
            this.z += (this.oz - this.z) * 0.1;
        }
    }
}

class Snow extends Point {
    constructor() {
        super();
        this.reset();
    }

    reset() {
        this.x = (Math.random() - 0.5) * width * 2;
        this.y = -height;
        this.z = (Math.random() - 0.5) * 1000;
        this.speed = 2 + Math.random() * 3;
    }

    update() {
        this.y += this.speed;
        if (this.y > height) this.reset();
    }
}

// Global State
const lights = [];
const snow = [];
const pulse = { active: false, y: 400 };

function init() {
    resize();
    generateSprites();

    for (let i = 0; i < config.particleCount; i++)
        lights.push(new TreeLight(i));
    for (let i = 0; i < config.snowCount; i++) snow.push(new Snow());

    // Events
    window.addEventListener("resize", resize);
    window.addEventListener("mousemove", (e) => {
        const nx = (e.clientX / width) * 2 - 1;
        const ny = (e.clientY / height) * 2 - 1;
        rotation.targetX = nx * 0.5;
        rotation.targetY = ny * 0.2;
    });

    // Touch for mobile rotation
    window.addEventListener(
        "touchmove",
        (e) => {
            const nx = (e.touches[0].clientX / width) * 2 - 1;
            const ny = (e.touches[0].clientY / height) * 2 - 1;
            rotation.targetX = nx * 0.5;
            rotation.targetY = ny * 0.2;
        },
        { passive: true }
    );

    canvas.addEventListener("mousedown", triggerPulse);
    canvas.addEventListener("touchstart", triggerPulse, { passive: true });

    // UI Controls
    document
        .getElementById("speedControl")
        .addEventListener(
            "input",
            (e) => (config.rotationSpeedMult = parseFloat(e.target.value))
        );
    document
        .getElementById("sizeControl")
        .addEventListener(
            "input",
            (e) => (config.globalSizeScale = parseFloat(e.target.value))
        );
    document
        .getElementById("lightModeBtn")
        .addEventListener("change", (e) => (config.lightMode = e.target.value));
    document.getElementById("colorBtn").addEventListener("click", (e) => {
        paletteIdx = (paletteIdx + 1) % PALETTES.length;
        e.target.innerText = PALETTES[paletteIdx].name + " Theme";
        lights.forEach((l) => (l.color = l.pickColor()));
        generateSprites(); // Regenerate for exact color match if we were doing complex gradients
    });

    animate();
}

function resize() {
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = width;
    canvas.height = height;
    cx = width / 2;
    cy = height / 2;
}

function triggerPulse() {
    if (pulse.active) return;
    pulse.active = true;
    pulse.y = 400; // Bottom
}

function animate() {
    requestAnimationFrame(animate);
    time++;

    // Camera smoothing
    rotation.x += (rotation.targetX - rotation.x) * 0.05;
    rotation.y += (rotation.targetY - rotation.y) * 0.05;

    // Logic Updates
    if (pulse.active) {
        pulse.y -= 10;
        if (pulse.y < -450) pulse.active = false;
    }

    // Background Clear (Dark fade for trails? No, crisp for million dollar look)
    ctx.fillStyle = "#020205";
    ctx.fillRect(0, 0, width, height);

    // Render List
    const drawList = [];

    // Process Lights
    lights.forEach((l) => {
        l.update();
        const p = l.project();
        if (p.visible) {
            drawList.push({ type: "light", obj: l, proj: p });
        }
    });

    // Process Snow
    snow.forEach((s) => {
        s.update();
        const p = s.project();
        if (p.visible) {
            drawList.push({ type: "snow", obj: s, proj: p });
        }
    });

    // Add Floor Glow (Fake Reflection)
    const floorScale = config.focalLength / (config.focalLength + 400); // approximate
    // Draw floor before particles? Or after? Floor is background.
    // Let's draw floor directly here
    const g = ctx.createRadialGradient(cx, cy + 300, 10, cx, cy + 300, 500);
    g.addColorStop(0, "rgba(30, 40, 60, 0.3)");
    g.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = g;
    ctx.save();
    ctx.scale(1, 0.3);
    ctx.translate(0, (cy + 300) * 2.3); // Adjust for scale
    ctx.fillRect(0, 0, width, height); // Simplified floor rect
    ctx.restore();

    // Sort by Depth (Painter's Algorithm)
    drawList.sort((a, b) => b.proj.depth - a.proj.depth);

    // Drawing Phase
    ctx.globalCompositeOperation = "lighter"; // Additive blending for "Lights" look

    drawList.forEach((item) => {
        const { x, y, scale } = item.proj;

        if (item.type === "light") {
            if (config.lightMode === "off") return;

            const l = item.obj;
            const color = l.tempColor || l.color;

            // Blink logic
            let alpha = 1;
            if (config.lightMode === "sparkle") {
                const blink = Math.sin(time * 0.05 + l.blinkOffset);
                alpha = 0.5 + blink * 0.3;
            } else {
                // Steady
                alpha = 0.9;
            }

            if (scale > 0) {
                const sprite = sprites[color];
                if (sprite) {
                    const s = l.sizeBase * scale * config.globalSizeScale * 8; // Multiplier for sprite size
                    ctx.globalAlpha = alpha;
                    ctx.drawImage(sprite, x - s / 2, y - s / 2, s, s);
                }
            }
        } else if (item.type === "snow") {
            const size = 2 * scale;
            ctx.fillStyle = "rgba(255,255,255,0.4)";
            ctx.globalAlpha = 0.6;
            ctx.beginPath();
            ctx.arc(x, y, size, 0, Math.PI * 2);
            ctx.fill();
        }
    });

    // Draw Star on Top
    drawStar();

    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
}

function drawStar() {
    // Project Star position (Top of tree is 0, -400, 0)
    const top = new Point();
    top.x = 0;
    top.y = -400;
    top.z = 0;
    const p = top.project();

    if (p.visible) {
        const size = 20 * p.scale;
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(time * 0.02);

        ctx.shadowBlur = 40;
        ctx.shadowColor = "#fff";
        ctx.fillStyle = "#fffae0";

        ctx.beginPath();
        for (let i = 0; i < 5; i++) {
            ctx.lineTo(
                Math.cos(((18 + i * 72) / 180) * Math.PI) * size,
                -Math.sin(((18 + i * 72) / 180) * Math.PI) * size
            );
            ctx.lineTo(
                (Math.cos(((54 + i * 72) / 180) * Math.PI) * size) / 2,
                (-Math.sin(((54 + i * 72) / 180) * Math.PI) * size) / 2
            );
        }
        ctx.closePath();
        ctx.fill();
        ctx.restore();
    }
}

// Boot
init();
